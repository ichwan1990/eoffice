<div class="page-title">
	<div class="title_left">
		<h3>Struktur Jabatan</h3>
	</div>
</div>

<div class="clearfix"></div>

<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<?= nested_pgw() ?>
		</div>
	</div>
</div>